# Data Structure Planning Table - Abdullah

| Operation | Data Structure | Reason |
|----------|----------------|--------|
| Create Deck | Linked List | Easy sequential traversal of 52 cards |
| Shuffle Deck | Array | Allows index‑based swapping using Fisher-Yates |
| Deal Card | Linked List | Removing from head is O(1) |
| Add Card to Player | Linked List | Append efficiently to tail |
| Compare Cards | Simple Variables | Only values needed for comparison |