# Pseudocode - Card Game (Abdullah)

FUNCTION CreateDeck()
    deck ← empty linked list
    FOR each suit IN [Hearts, Diamonds, Clubs, Spades]
        FOR value from 2 to Ace
            INSERT card(value, suit) at end of deck
    END FOR
END FUNCTION

FUNCTION ShuffleDeck(deck)
    arr ← linked list converted to array
    FOR i from length(arr) DOWNTO 1
        j ← random(1, i)
        SWAP arr[i], arr[j]
    END FOR
    RETURN arr converted back to linked list
END FUNCTION

FUNCTION DealCard(deck)
    card ← deck.head
    deck.head ← deck.head.next
    RETURN card
END FUNCTION

FUNCTION PlayRound(player1, player2)
    c1 ← player1.play_card()
    c2 ← player2.play_card()
    winner ← compare(c1, c2)
    RETURN winner
END FUNCTION

FUNCTION Compare(c1, c2)
    IF value(c1) > value(c2)
        RETURN player1
    ELSE IF value(c2) > value(c1)
        RETURN player2
    ELSE
        RETURN tie
END FUNCTION